# Player.gd
extends "res://Scripts/World Elements/Racers/Racer.gd"

# === Controls & Drift/Hop Settings ===
const DRIFT_MIN_SPEED := 60.0
const DRIFT_STEER_MULT := 8.86
const DRIFT_SPEED_MULT := 0.92
const DRIFT_BUILD_RATE := 28.0
const TURBO_THRESHOLD_SMALL := 35.0
const TURBO_THRESHOLD_BIG := 80.0
const TURBO_SMALL_MULT := 1.005
const TURBO_BIG_MULT := 1.02
const TURBO_TIME := 0.25

# === Nitro (replaces hop) ===
const NITRO_DURATION := 0.32          # same window length as old hop
const NITRO_MULT := 1.002            # same tiny speed bump as old hop
const NITRO_MIN_ACTIVATE_FRAC := 0.01  # need ≥35% to engage AND to stay on
@export var NITRO_TEMP_CAP_FACTOR := 1.10  # brief headroom while nitro runs

var _nitro_timer := 0.0
var _nitro_latched := false             # persists until you toggle it off

# === Nitro gauge (hold-to-drain, release-to-refill) ===
@export var NITRO_CAPACITY_S := 3.0      # seconds of continuous nitro from full
@export var NITRO_REFILL_S   := 2.4      # seconds to refill from empty to full
var _nitro_charge: float = 1.0           # 0..1 gauge

# HUD hookup (set this to your RaceHUD node in the inspector)
@export var hud_path: NodePath
var _hud: Node = null

@export var TERRAIN_DECAY_HALF_LIFE := 0.016   # slows down over ~0.18s when terrain gets worse
@export var TERRAIN_RECOVER_HALF_LIFE := 0.008 # recovers a bit faster when terrain improves
var _terrain_mult_s := 1.0                    # smoothed terrain multiplier

var _turbo_pulse := 1.0
var _hop_timer := 0.0
var _hop_boost_timer := 0.0
var _is_drifting := false
var _drift_dir := 0
var _drift_charge := 0.0
var _turbo_timer := 0.0
var _base_sprite_offset_y := 0.0
const FRAMES_PER_ROW := 12

const TURN_STRAIGHT_INDEX := 0
const TURN_INCREASES_TO_RIGHT := true

const BASIC_MAX := 3
const DRIFT_MAX := 4
const LEAN_LERP_SPEED := 14.0
const STEER_SIGN := -1.0

var _lean_visual := 0.0
var _lean_left_visual := false

# === Sprite drift behavior (SNES-ish) ===
const DRIFT_WOBBLE_FREQ := 8
const DRIFT_WOBBLE_AMPL := 0.40
const DRIFT_BASE_BIAS := 0.7
const DRIFT_RELEASE_BURST_TIME := 0.24

@export var drift_particle_path: NodePath = ^"Road Type Effects/Right Wheel Special"
@export var sparks_particle_path: NodePath = ^"Road Type Effects/Left Wheel Special" # or a GPUParticles2D if you have one

var _drift_wobble_phase := 0.0
var _drift_release_timer := 0.0

const POST_DRIFT_SETTLE_TIME := 0.18
var _post_settle_time := 0.0

const DRIFT_STEER_DEADZONE := 0.25
const DRIFT_ARM_WINDOW := 0.20
var _drift_arm_timer := 0.0

const DRIFT_MIN_TURN_BIAS := 0.55
const DRIFT_VISUAL_STEER_GAIN := 0.22

const DRIFT_BREAK_DEADZONE := 0.12
const DRIFT_BREAK_GRACE := 0.10
const DRIFT_REVERSE_BREAK := 0.25
const POST_DRIFT_SETTLE_TIME_BREAK := 0.12

# --- Brief cap headroom when drift starts (avoids hard clamp) ---
@export var DRIFT_TEMP_CAP_FACTOR := 1.08
const DRIFT_CAP_ENTRY_TIME := 0.40  # seconds of extra headroom after drift starts

@export var RELEASE_BOOST_HALF_LIFE := 0.18   # seconds to halve the release boost
var _release_boost := 0.0                     # extra multiplier above 1.0 that decays

var _drift_cap_timer := 0.0

var _drift_break_timer := 0.0
const TAU := PI * 2.0

# --- SNES-ish feel controls ---
const DRIFT_GRIP := 0.55
const DRIFT_SLIP_GAIN := 0.9
const DRIFT_SLIP_DAMP := 6.0
var _drift_side_slip := 0.0

# === Drift Spin-out ===
const SPIN_MIN_STEER := 0.55          # must steer at least this hard while drifting
const SPIN_BUILD_BASE := 10.0         # base fill per second while drifting
const SPIN_BUILD_STEER_GAIN := 26.0   # extra fill scaled by |steer|
const SPIN_THRESHOLD := 100.0         # trip point
const SPIN_DURATION := 0.80           # total time of the spin state
const SPIN_SPEED_MULT := 0.60         # slow-down while spinning
const SPIN_ANIM_CYCLES := 2.0         # how many “L→R” swaps during SPIN_DURATION
const SPIN_RECOVER_STEER_LOCK := 0.12 # brief steer lock after recovery

var _spin_meter := 0.0
var _is_spinning := false
var _spin_timer := 0.0
var _spin_phase := 0.0
var _post_spin_lock := 0.0

# === Item (Mushroom) Boost ===
const ITEM_BOOST_MULT := 6.75     # how strong the mushroom boost is
const ITEM_BOOST_TIME := 0.35     # how long it lasts (seconds)
const ITEM_COOLDOWN := 3       # small cooldown before you can use another

var _item_boost_timer := 0.0
var _item_cooldown_timer := 0.0

var _dust_was_on := false
var _sparks_was_on := false

var _has_base_sprite_offset: bool = false
@onready var _sfx: Node = get_node_or_null(^"Audio")  # KartSFX.gd lives here

# --- Item boost terrain compensation (tune to taste) ---
@export var ITEM_COMP_OFF_ROAD := 1.40   # extra “anti-slow” while boosting on OFF_ROAD
@export var ITEM_COMP_GRAVEL  := 1.20   # extra “anti-slow” while boosting on GRAVEL

# --- Wall collision tuning ---
@export var WALL_RESTITUTION      := 0.35   # 0 = no bounce, 1 = perfectly bouncy
@export var WALL_SLIDE_KEEP       := 0.85   # keep this fraction of tangential speed
@export var WALL_SEPARATION_EPS   := 0.50   # small nudge away from wall (pixels)
@export var WALL_BUMP_STRENGTH    := 1.0    # impulse fed into SetCollisionBump()
@export var WALL_HIT_COOLDOWN_S   := 0.10   # min time between bumps

@export var REAR_BUMP_COOLDOWN_MULT := 2.4  # extend cooldown on rear shoves
var _last_map_forward: Vector3 = Vector3(0, 0, 1)  # cached last mapForward

var _wall_hit_cd := 0.0
var _primed_sprite := false

@export var ITEM_TEMP_CAP_FACTOR  := 1.60  # temporary headroom while item is active
@export var TURBO_TEMP_CAP_FACTOR := 1.45  # temporary headroom while turbo is active
@export var HOP_TEMP_CAP_FACTOR   := 1.10  # tiny headroom while hop is active

@export var BUMP_SFX_MIN_IMPULSE: float = 1.10   # >1.0 skips wall axis-bumps, catches racer bumps
@export var BUMP_SFX_COOLDOWN_S: float = 0.10    # avoid rapid repeats
var _bump_sfx_cd := 0.0

@export var DUST_ON_MULT := 3.0     # how dense when ON (try 2.0–5.0)
@export var DUST_OFF_MULT := 1.0    # base density when OFF
@export var DUST_SMOOTH_RATE := 10.0 # larger = snappier easing

var _dust_mult_target := 1.0
var _dust_mult := 1.0
var _dust_base := -1

# --- Per-entity collision size (used only when SpriteHandler.collision_radius_mode == 2)
@export var collision_radius_px: float = 8.0  # try 6–12 px until it feels right

@export var nitro_shader_path: String = "res://Scripts/Shaders/NitroPulse.gdshader"
@export var nitro_glow_color: Color = Color(0.55, 0.9, 1.0, 1.0)
@export var nitro_outline_px: float = 2.0
@export var nitro_chroma_max_px: float = 3.0     # how far RGB splits at peak
@export var nitro_intensity_max: float = 1.0     # cap the shader “strength”

var _nitro_mat: ShaderMaterial = null
var _nitro_prev_material: Material = null

# --- Character color (Yoshi-style hue swap) ---
@export_file("*.gdshader") var yoshi_shader_path: String = "res://Scripts/Shaders/YoshiSwap.gdshader"
@export var yoshi_source_hue: float = 0.97
@export var yoshi_tolerance: float = 0.045
@export var yoshi_edge_soft: float = 0.20
var _yoshi_mat: ShaderMaterial = null

# === Award Spin (celebration) ===
const AWARD_SPIN_DURATION := 0.85    # seconds
const AWARD_SPIN_CYCLES   := 1.50    # how many L↔R swaps over the duration

var _is_award_spin := false
var _award_spin_timer := 0.0
var _award_spin_phase := 0.0         # 0..N cycles
var _award_spin_dir := 1             # +1 = right-first, -1 = left-first

# === Award Spin (celebration) ===
const AWARD_SPIN_ROTATIONS := 2.0   # exactly two full 360s
var _award_spin_elapsed := 0.0

var _nitro_was_active := false
var can_nitro: = false

const NITRO_ENGAGE_FRAC := 0.12     # engage when ≥ 12%
const NITRO_DISENGAGE_FRAC := 0.06  # stay on until < 6% (prevents chatter)

var _nitro_active_runtime := false   # true only while nitro is actually on

var DEFAULT_POINTS: PackedVector2Array = PackedVector2Array([
	Vector2(920, 584),
	Vector2(950, 607),
	Vector2(920, 631),
	Vector2(950, 655),
	Vector2(920, 679),
	Vector2(950, 703),
	Vector2(920, 727),
	Vector2(950, 751)
])

var _device_id: int = -1
var _btn_prev := {}  # button -> bool (edge detect for “just pressed”)

var _player_index: int = 1   # 1 = P1, 2 = P2 (World can set)

func SetPlayerIndex(idx: int) -> void:
	_player_index = 1
	if idx > 1:
		_player_index = idx
	# default mapping by index if a device wasn’t forced yet
	if _device_id < 0:
		var dev_from_idx := _player_index - 1
		if dev_from_idx < 0:
			dev_from_idx = 0
		_device_id = dev_from_idx

func SetInputDevice(id: int) -> void:
	_device_id = id
	if _device_id < 0:
		_device_id = 0

func ReturnCollisionRadiusUV() -> float:
	# Convert the pixel radius to UV using your map’s real width.
	var map_w := 1024.0
	var p := get_node_or_null(pseudo3d_ref)
	if p is Sprite2D and (p as Sprite2D).texture:
		map_w = float((p as Sprite2D).texture.get_size().x)
	return clamp(collision_radius_px / map_w, 0.0001, 0.05)

func _compute_temp_cap(base_cap: float) -> float:
	var cap := base_cap

	# item headroom
	if _item_boost_timer > 0.0:
		var c := base_cap * ITEM_TEMP_CAP_FACTOR
		if cap < c:
			cap = c

	# turbo headroom
	if _turbo_timer > 0.0:
		var c := base_cap * TURBO_TEMP_CAP_FACTOR
		if cap < c:
			cap = c

	# nitro (replaces hop) headroom
	if _nitro_timer > 0.0:
		var c := base_cap * NITRO_TEMP_CAP_FACTOR
		if cap < c:
			cap = c

	# brief headroom after drift starts
	if _drift_cap_timer > 0.0:
		var c := base_cap * DRIFT_TEMP_CAP_FACTOR
		if cap < c:
			cap = c

	# spin limits speed
	if _is_spinning:
		var c := base_cap * SPIN_SPEED_MULT
		if cap > c:
			cap = c

	return cap

func _prime_sprite_grid_once() -> void:
	if _primed_sprite:
		return
	var spr := ReturnSpriteGraphic()
	if spr == null:
		return

	# Sprite2D (grid sheet)
	if spr is Sprite2D:
		var s := spr as Sprite2D
		# force grid mode; showing the whole texture for a frame is the usual culprit
		s.region_enabled = false
		if s.hframes != DIRECTIONS:
			s.hframes = DIRECTIONS
			s.vframes = 1
		s.flip_h = false
		s.frame = TURN_STRAIGHT_INDEX  # single frame (front)
		_primed_sprite = true
		return

	# AnimatedSprite2D (fallback)
	if spr.has_method("stop"):
		spr.stop()
	if "frame" in spr:
		spr.frame = TURN_STRAIGHT_INDEX
	_primed_sprite = true
	
func _apply_item_terrain_comp(rt: int) -> void:
	if _item_boost_timer <= 0.0:
		return
	# Don’t compensate for SINK/WALL; they’re “hard stops”.
	if rt == Globals.RoadType.OFF_ROAD:
		_speedMultiplier = max(_speedMultiplier, ITEM_BOOST_MULT * ITEM_COMP_OFF_ROAD)
	elif rt == Globals.RoadType.GRAVEL:
		_speedMultiplier = max(_speedMultiplier, ITEM_BOOST_MULT * ITEM_COMP_GRAVEL)

func _spr_or_null() -> CanvasItem:
	return ReturnSpriteGraphic()

func _set_frame_idx(dir_idx: int) -> void:
	var spr := _spr_or_null()
	if spr == null: return

	if spr is Sprite2D:
		var s := spr as Sprite2D
		if sheet_uses_mirroring:
			# 6 columns on sheet; use flip for the other 6
			var HALF := 12
			var idx := (dir_idx % (HALF * 2) + (HALF * 2)) % (HALF * 2)
			var left_side := idx >= HALF
			var col := idx % HALF
			if s.hframes != HALF:
				s.hframes = HALF
				s.vframes = 1
			s.frame = col
			s.flip_h = left_side
		else:
			# full 12 unique frames — no flip needed
			if s.hframes != DIRECTIONS:
				s.hframes = DIRECTIONS
				s.vframes = 1
			s.flip_h = false
			s.frame = clamp(dir_idx, 0, DIRECTIONS - 1)
	elif "frame" in spr:
		spr.frame = clamp(dir_idx, 0, DIRECTIONS - 1)

func _ready() -> void:
	var spr := ReturnSpriteGraphic()
	if spr == null:
		await get_tree().process_frame
		spr = ReturnSpriteGraphic()
	if spr == null:
		push_error("Player.gd: sprite_graphic_path not found")
		return

	_prime_sprite_grid_once()
	_base_sprite_offset_y = spr.offset.y
	add_to_group("racers")

	# If world didn't set device yet, map by index (P1->0, P2->1)
	if _device_id < 0:
		var idx := _player_index
		if idx < 1:
			idx = 1
		_device_id = idx - 1
		if _device_id < 0:
			_device_id = 0

	# Apply THIS slot's palette
	_ensure_yoshi_material()
	_apply_player_palette_from_globals()

	_hud = get_node_or_null(hud_path)
	if _hud == null:
		_hud = get_tree().get_first_node_in_group("race_hud")

func _process(_dt: float) -> void:
	# publish camera/player position for pseudo-3D projection
	Globals.set_camera_map_position(get_player_map_position())
	if Engine.get_process_frames() % 30 == 0:
		var v := ReturnPlayerInput()
		#print("INPUT steer=", v.x, " throttle=", v.y)

func _set_frame(idx: int) -> void:
	var spr := ReturnSpriteGraphic()
	if spr == null:
		return   # sprite not ready this frame

	# Sprite2D sheet (preferred)
	if spr is Sprite2D:
		var s := spr as Sprite2D
		# ensure grid; safe to repeat
		if s.hframes != DIRECTIONS:
			s.hframes = DIRECTIONS
			s.vframes = 1
		# DO NOT touch s.region_enabled here; not needed for hframes/vframes
		s.frame = clamp(idx, 0, DIRECTIONS - 1)
		return

	# AnimatedSprite2D fallback
	if spr.has_method("set_frame"):
		spr.frame = clamp(idx, 0, DIRECTIONS - 1)

func _set_turn_amount_in_range(right_amount: float, is_left: bool, range_max: int) -> void:
	right_amount = clamp(right_amount, 0.0, 1.0)
	range_max = clamp(range_max, 0, FRAMES_PER_ROW - 1)

	var steps := float(range_max)
	var delta := int(floor(right_amount * steps + 0.0001))

	var idx: int
	if TURN_INCREASES_TO_RIGHT:
		idx = TURN_STRAIGHT_INDEX + delta
	else:
		idx = TURN_STRAIGHT_INDEX - delta

	_set_frame(idx)

	# keep outward-lean mirroring while drifting *and* during release/settle
	if _in_drift_visual_state():
		_set_flip_h(not is_left)
	else:
		_set_flip_h(is_left)

# --- helper: null-safe flip ---
func _set_flip_h(val: bool) -> void:
	var spr := ReturnSpriteGraphic()
	if spr == null:
		return
	if spr is Sprite2D:
		(spr as Sprite2D).flip_h = val
	elif "flip_h" in spr:
		spr.flip_h = val

func _choose_and_apply_frame(dt: float) -> void:
	var steer := _inputDir.x
	var target_left := steer > 0.0
	var target_mag = abs(steer)
	var max_range := BASIC_MAX

	# AWARD SPIN: two fast 360s using the 12-frame sheet
	if _is_award_spin:
		_apply_award_spin_frames()
		return

	# SPIN VISUAL: play left turn frames, then a flipped version, repeatedly.
	if _is_spinning:
		# phase in [0,1); first half = sweep A, second half = sweep B
		var ph := fposmod(_spin_phase, 1.0)
		var first_half := ph < 0.5
		var t := 0.0
		if first_half:
			t = ph * 2.0
		else:
			t = (ph - 0.5) * 2.0  # 0..1 within each half

		var frames := FRAMES_PER_ROW
		var steps := frames - 1
		var step := int(floor(t * steps + 0.0001))  # 0..steps

		# Decide direction: right-first = forward (0..11), left-first = backward (11..0)
		var dir_right_first := (_drift_dir >= 0)

		var seq_a := 0         # first-half sweep
		var seq_b := 0         # second-half sweep (reverse of A)

		if dir_right_first:
			# RIGHT-FIRST: 0..11 then 11..0
			seq_a = step
			seq_b = steps - step
		else:
			# LEFT-FIRST: 11..0 then 0..11
			seq_a = steps - step
			seq_b = step

		var seq := 0
		if first_half:
			seq = seq_a
		else:
			seq = seq_b

		# Map to actual sheet direction (if your sheet increases to the right or left)
		var inc_right := TURN_INCREASES_TO_RIGHT
		var idx := seq
		if not inc_right:
			idx = steps - seq

		# Safety
		idx = clamp(idx, 0, steps)

		# Use mirroring-aware setter so 6+flip sheets animate correctly
		_set_frame(idx)
		return

	if _is_drifting:
		_lean_left_visual = (_drift_dir < 0)
		_drift_wobble_phase += dt * DRIFT_WOBBLE_FREQ * TAU
		var wobble := sin(_drift_wobble_phase) * DRIFT_WOBBLE_AMPL
		var steer_intensity = abs(_inputDir.x)

		var cap := 0.93
		target_mag = clamp(DRIFT_BASE_BIAS + wobble + steer_intensity * DRIFT_VISUAL_STEER_GAIN, 0.0, cap)

		var steps := float(DRIFT_MAX)
		var frac := fmod(target_mag * steps, 1.0)
		if frac < 0.08:
			target_mag += 0.04
		elif frac > 0.92:
			target_mag -= 0.04
		target_mag = clamp(target_mag, 0.0, cap)

		max_range = DRIFT_MAX

		_emit_dust(true)
		if _drift_charge >= TURBO_THRESHOLD_BIG:
			_emit_sparks(true)
			_set_sparks_color(Color(0.35, 0.6, 1.0))
		elif _drift_charge >= TURBO_THRESHOLD_SMALL:
			_emit_sparks(true)
			_set_sparks_color(Color(1.0, 0.55, 0.2))
		else:
			_emit_sparks(false)
	else:
		var t = clamp(dt * LEAN_LERP_SPEED, 0.0, 1.0)
		_lean_visual = lerp(_lean_visual, target_mag, t)

		if target_left != _lean_left_visual and _lean_visual < 0.15:
			_lean_left_visual = target_left
		elif target_left != _lean_left_visual and target_mag > 0.35:
			_lean_left_visual = target_left

		max_range = BASIC_MAX
		target_mag = _lean_visual
		_emit_dust(false)
		_emit_sparks(false)

	if _drift_release_timer > 0.0:
		_drift_release_timer -= dt
		target_mag = 1.0
		max_range = DRIFT_MAX
	elif _post_settle_time > 0.0:
		_post_settle_time = max(0.0, _post_settle_time - dt)
		var u := 1.0 - (_post_settle_time / POST_DRIFT_SETTLE_TIME)
		var eased := 1.0 - pow(1.0 - u, 3)
		target_mag = lerp(1.0, 0.0, eased)
		max_range = DRIFT_MAX
		_lean_left_visual = (_drift_dir < 0)
		_emit_dust(false)
		_emit_sparks(false)

	_set_turn_amount_in_range(target_mag, _lean_left_visual, max_range)

func Setup(mapSize : int) -> void:
	SetMapSize(mapSize)

func Update(mapForward : Vector3) -> void:
	_last_map_forward = mapForward
	
	if _isPushedBack:
		ApplyCollisionBump()
	
	var dt := get_process_delta_time()
	_bump_sfx_cd = max(0.0, _bump_sfx_cd - dt)

	# Smoothly decay the post-drift release boost
	if _release_boost > 0.0:
		var a := 1.0 - pow(0.5, dt / max(0.0001, RELEASE_BOOST_HALF_LIFE))
		_release_boost = max(0.0, _release_boost - _release_boost * a)

	if _drift_cap_timer > 0.0:
		_drift_cap_timer = max(0.0, _drift_cap_timer - dt)

	if _post_spin_lock > 0.0:
		_post_spin_lock = max(0.0, _post_spin_lock - dt)

	# Read steer/throttle from THIS device only
	var input_vec := ReturnPlayerInput()

	# Spinout & celebration ticks
	_spinout_update_meter(dt, input_vec)
	_spinout_tick(dt)
	_award_spin_tick(dt)

	# -------------------------
	# ITEM (Button B) — device-scoped edge detection
	# -------------------------
	var now_b := Input.is_joy_button_pressed(_device_id, JOY_BUTTON_B)
	var prev_b := bool(_btn_prev.get(JOY_BUTTON_B, false))
	_btn_prev[JOY_BUTTON_B] = now_b
	var item_just := (now_b and not prev_b)

	if item_just:
		if (not _is_spinning) and _item_cooldown_timer <= 0.0:
			_item_boost_timer    = ITEM_BOOST_TIME
			_item_cooldown_timer = ITEM_BOOST_TIME + ITEM_COOLDOWN
			_emit_sparks(true)
			_set_sparks_color(Color(0.6, 1.0, 0.4))  # greenish boost flash

	# Drift / Nitro handling (RB edge & hold) is done inside this helper.
	# It uses ONLY this device’s RB and manages drift arm + visual nitro pulse.
	if not _is_spinning:
		_handle_hop_and_drift(input_vec)

	# Timers decay (and cooldown actually counts down)
	if _item_boost_timer > 0.0:
		_item_boost_timer = max(0.0, _item_boost_timer - dt)
	if _item_cooldown_timer > 0.0:
		_item_cooldown_timer = max(0.0, _item_cooldown_timer - dt)
	if _turbo_timer > 0.0:
		_turbo_timer = max(0.0, _turbo_timer - dt)

	# -------------------------
	# NITRO (RB) — device-scoped, hysteresis
	# -------------------------
	# Do NOT edge-detect RB here (edge is used by _handle_hop_and_drift); just read current hold.
	var nitro_down := Input.is_joy_button_pressed(_device_id, JOY_BUTTON_RIGHT_SHOULDER)

	# Latch behavior: keep whatever your game sets elsewhere; here we don't toggle it on.
	var nitro_blocked := _is_drifting or _is_spinning
	var requesting := (_nitro_latched or nitro_down) and not nitro_blocked

	if _nitro_active_runtime:
		if (not requesting) or (_nitro_charge <= NITRO_DISENGAGE_FRAC):
			_nitro_active_runtime = false
	else:
		if requesting and (_nitro_charge >= NITRO_ENGAGE_FRAC):
			_nitro_active_runtime = true

	# One-shot SFX on rising edge
	if _nitro_active_runtime and not _nitro_was_active:
		if _sfx and _sfx.has_method("play_nitro_start"):
			_sfx.play_nitro_start()
		elif _sfx and _sfx.has_method("play_boost"):
			_sfx.play_boost()

	# Drain/refill gauge (never refill while requesting)
	var drain_rate  = 1.0 / max(0.001, NITRO_CAPACITY_S)
	var refill_rate = 1.0 / max(0.001, NITRO_REFILL_S)

	if _nitro_active_runtime:
		_nitro_charge = max(0.0, _nitro_charge - drain_rate * dt)
	else:
		if not requesting and not nitro_blocked:
			_nitro_charge = min(1.0, _nitro_charge + refill_rate * dt)

	# Drive visuals flag (the shader pulse itself is primed in _handle_hop_and_drift)
	_nitro_timer = 1.0 if _nitro_active_runtime else 0.0
	_nitro_was_active = _nitro_active_runtime

	_apply_nitro_fx(mapForward)
	_push_nitro_hud()

	# DRIFT side-slip feed (visual/feel), no change when spinning
	var right_vec := Vector3(-mapForward.z, 0.0, mapForward.x).normalized()
	if _is_drifting and not _is_spinning:
		var speed := ReturnVelocity().length()
		var steer_amt = abs(_inputDir.x)
		var feed = DRIFT_SLIP_GAIN * speed * steer_amt
		var outward_sign := 1.0
		if _drift_dir >= 0:
			outward_sign = -1.0
		_drift_side_slip = lerp(_drift_side_slip, outward_sign * feed, clamp(dt * 4.0, 0.0, 1.0))
	else:
		_drift_side_slip = lerp(_drift_side_slip, 0.0, clamp(dt * DRIFT_SLIP_DAMP, 0.0, 1.0))

	# Predict next pos
	var nextPos : Vector3 = _mapPosition + ReturnVelocity()
	var nextPixelPos : Vector2i = Vector2i(ceil(nextPos.x), ceil(nextPos.z))

	# Walls (X then Z)
	if _has_collision_api():
		if _collisionHandler.IsCollidingWithWall(Vector2i(ceil(nextPos.x), ceil(_mapPosition.z))):
			nextPos.x = _mapPosition.x
			SetCollisionBump(Vector3(-sign(ReturnVelocity().x), 0.0, 0.0))
			if _wall_hit_cd <= 0.0 and _sfx and _sfx.has_method("play_collision"):
				_sfx.play_collision()
				_wall_hit_cd = WALL_HIT_COOLDOWN_S

	if _has_collision_api():
		if _collisionHandler.IsCollidingWithWall(Vector2i(ceil(_mapPosition.x), ceil(nextPos.z))):
			nextPos.z = _mapPosition.z
			SetCollisionBump(Vector3(0.0, 0.0, -sign(ReturnVelocity().z)))
			if _wall_hit_cd <= 0.0 and _sfx and _sfx.has_method("play_collision"):
				_sfx.play_collision()
				_wall_hit_cd = WALL_HIT_COOLDOWN_S

	# Terrain
	var curr_rt := Globals.RoadType.ROAD
	if _has_collision_api():
		curr_rt = _collisionHandler.ReturnCurrentRoadType(Vector2i(ceil(nextPos.x), ceil(nextPos.z)))
	HandleRoadType(Vector2i(ceil(nextPos.x), ceil(nextPos.z)), curr_rt)

	# apply drift side-slip after wall clamps
	nextPos += right_vec * _drift_side_slip * dt

	# Terrain multiplier smoothing
	var terrain_raw := _speedMultiplier
	if terrain_raw <= 0.0:
		terrain_raw = 1.0

	var hl: float = TERRAIN_DECAY_HALF_LIFE
	if terrain_raw >= _terrain_mult_s:
		hl = TERRAIN_RECOVER_HALF_LIFE

	var a := 1.0 - pow(0.5, dt / max(0.0001, hl))
	_terrain_mult_s = _terrain_mult_s + (terrain_raw - _terrain_mult_s) * a

	# BOOST (separate from terrain)
	var boost_mult := _recompute_speed_multiplier()

	# combine & clamp
	_speedMultiplier = _terrain_mult_s
	_apply_item_terrain_comp(curr_rt)
	_speedMultiplier = _terrain_mult_s * boost_mult
	if _speedMultiplier < 0.01:
		_speedMultiplier = 0.01

	# Move
	SetMapPosition(nextPos)
	UpdateMovementSpeed()
	UpdateVelocity(mapForward)

	# Visuals / sprite
	_choose_and_apply_frame(get_process_delta_time())
	_wall_hit_cd = max(0.0, _wall_hit_cd - dt)

func _push_nitro_hud() -> void:
	if _hud == null:
		return
	# active if timer > 0 (shader on) OR latched/held with charge remaining
	var is_active := (_nitro_timer > 0.0) or (_nitro_latched and _nitro_charge > 0.0)
	if _hud.has_method("SetNitro"):
		# expects (level_0_1, active_bool) — see RaceHUD.gd below
		_hud.call("SetNitro", _nitro_charge, is_active)

func ReturnPlayerInput() -> Vector2:
	# Left stick X (or D-Pad) on _device_id only
	var ax := Input.get_joy_axis(_device_id, JOY_AXIS_LEFT_X)
	var steer_raw = clamp(ax, -1.0, 1.0)

	# D-Pad override to snap full left/right
	if Input.is_joy_button_pressed(_device_id, JOY_BUTTON_DPAD_LEFT):
		steer_raw = -1.0
	elif Input.is_joy_button_pressed(_device_id, JOY_BUTTON_DPAD_RIGHT):
		steer_raw = 1.0

	if abs(steer_raw) < STEER_DEADZONE:
		steer_raw = 0.0

	var steer_mag = abs(steer_raw)
	if steer_mag > 0.0:
		steer_mag = pow(steer_mag, max(0.01, STEER_CURVE))

	var steer_shaped = steer_mag
	if steer_raw < 0.0:
		steer_shaped = -steer_mag

	var steer = steer_shaped * STEER_GAIN * STEER_SIGN

	# A = Forward, B = Brake (same on both pads, per-device)
	var forward := 0.0
	if Input.is_joy_button_pressed(_device_id, JOY_BUTTON_A):
		forward = 1.0
	var brake := 0.0
	if Input.is_joy_button_pressed(_device_id, JOY_BUTTON_B):
		brake = 1.0

	var throttle := -forward
	if brake > 0.01:
		throttle = -brake

	if _is_spinning:
		_inputDir = Vector2.ZERO
		return _inputDir

	_inputDir = Vector2(steer, throttle)
	return _inputDir

func _handle_hop_and_drift(input_vec : Vector2) -> void:
	var dt := get_process_delta_time()

	# Right Shoulder (RB) on _device_id drives both nitro pulse and drift hold
	var now_rb := Input.is_joy_button_pressed(_device_id, JOY_BUTTON_RIGHT_SHOULDER)
	var prev_rb := bool(_btn_prev.get(JOY_BUTTON_RIGHT_SHOULDER, false))
	_btn_prev[JOY_BUTTON_RIGHT_SHOULDER] = now_rb

	var nitro_down := now_rb
	var nitro_just := (now_rb and not prev_rb)
	var drift_down := now_rb

	var moving_fast := _movementSpeed >= DRIFT_MIN_SPEED
	var steer_abs = abs(input_vec.x)
	var steer_sign = sign(input_vec.x)

	# Arm drift on nitro tap
	if nitro_just and not _is_drifting:
		_drift_arm_timer = DRIFT_ARM_WINDOW
		if _sfx != null and _sfx.has_method("play_drift"):
			_sfx.play_drift()

	# Visual nitro pulse (only if there’s charge)
	if nitro_down and _nitro_charge >= NITRO_MIN_ACTIVATE_FRAC:
		_nitro_timer = 1.0

	# decay arm timer
	if _drift_arm_timer > 0.0:
		_drift_arm_timer = max(0.0, _drift_arm_timer - dt)

	# Start drift if armed, fast enough, and steering clearly
	if (not _is_drifting) and drift_down and (_drift_arm_timer > 0.0) and moving_fast and (steer_abs >= DRIFT_STEER_DEADZONE):
		var dir := 1
		if steer_sign < 0.0:
			dir = -1
		_start_drift_snes(dir)

	# While drifting and holding drift
	if _is_drifting and drift_down:
		var sign_dir := float(_drift_dir)
		var target_bias = DRIFT_MIN_TURN_BIAS + (steer_abs * DRIFT_STEER_MULT)
		var clamped = clamp(sign_dir * target_bias, -1.0, 1.0)
		var grip_t = clamp(dt * (DRIFT_GRIP * 10.0), 0.0, 1.0)
		_inputDir.x = lerp(_inputDir.x, clamped, grip_t)

		var add = (0.75 + 0.25 * steer_abs) * DRIFT_BUILD_RATE * dt
		_drift_charge = max(0.0, _drift_charge + add)

		# quick-cancel rules
		if steer_sign != 0 and steer_sign == -_drift_dir and steer_abs >= DRIFT_REVERSE_BREAK:
			_cancel_drift_no_award(POST_DRIFT_SETTLE_TIME_BREAK)
		elif steer_abs < DRIFT_BREAK_DEADZONE:
			_drift_break_timer += dt
			if _drift_break_timer >= DRIFT_BREAK_GRACE:
				_cancel_drift_no_award(POST_DRIFT_SETTLE_TIME_BREAK)
		else:
			_drift_break_timer = 0.0

	# Release drift
	if _is_drifting and not drift_down:
		_end_drift_with_award()

# SNES-like drift start: lock direction, fixed slip "set", reset counters.
func _start_drift_snes(dir: int) -> void:
	_is_drifting = true

	if _sfx and _sfx.has_method("set_drift_active"):
		_sfx.set_drift_active(true)
		
	if dir < 0:
		_drift_dir = -1
	else:
		_drift_dir = 1

	# brief headroom to avoid instant cap slap when entering drift fast
	_drift_cap_timer = DRIFT_CAP_ENTRY_TIME

	_drift_wobble_phase = 0.0
	_drift_break_timer = 0.0
	_drift_charge = 0.0
	_lean_left_visual = (_drift_dir < 0)
	_post_settle_time = 0.0

	# Fixed outward slip feel (SMK vibe): small one-off outward impulse
	var outward_sign := 1.0
	if _drift_dir >= 0:
		outward_sign = -1.0
	_drift_side_slip += outward_sign * 0.65

	# No drift slow here; drifting is speed-neutral
	_emit_dust(true)
	_emit_sparks(false)

func _strip_gamepad_from_actions() -> void:
	var acts := ["Forward","Left","Right","Brake","Hop","Drift","Item","RearView","Nitro"]
	for a in acts:
		var to_remove: Array = []
		for ev in InputMap.action_get_events(a):
			if ev is InputEventJoypadButton or ev is InputEventJoypadMotion:
				to_remove.append(ev)
		for e in to_remove:
			InputMap.action_erase_event(a, e)

func _apply_hop_sprite_offset() -> void:
	# intentionally empty — nitro has no visual bob
	return

func _try_get_node(path: String) -> Node:
	if has_node(path):
		return get_node(path)
	return null
	
func _get_drift_node() -> Node:
	var n := get_node_or_null(drift_particle_path)
	if n == null: n = find_child("DriftDust", true, false)
	return n

func _get_sparks_node() -> Node:
	var n := get_node_or_null(sparks_particle_path)
	if n == null: n = find_child("DriftSparks", true, false)
	return n

func _set_sparks_color(col: Color) -> void:
	var p := _get_sparks_node()
	if p != null and p is GPUParticles2D:
		p.process_material.color = col

func _emit_sparks(on: bool) -> void:
	var p := _get_sparks_node()
	if p != null and p is GPUParticles2D:
		p.emitting = on
	elif p is CanvasItem:
		(p as CanvasItem).visible = on

func _emit_dust(on: bool) -> void:
	var p := _get_drift_node()
	if p == null:
		return

	# Set target density; don't yank the system immediately
	_dust_mult_target = DUST_ON_MULT if on else DUST_OFF_MULT

	# Rising edge detection
	var rising := on and (not _dust_was_on)
	_dust_was_on = on

	if p is GPUParticles2D:
		var gp := p as GPUParticles2D
		if _dust_base < 0:
			_dust_base = max(1, gp.amount)

		if on:
			# On edge only: force a fresh emission so it never looks stuck
			if rising:
				gp.emitting = false
				gp.emitting = true
				gp.restart()
		else:
			# Only turn OFF once we've eased back to base
			if gp.emitting and _dust_mult <= DUST_OFF_MULT + 0.01:
				gp.emitting = false
		return

	if p is AnimatedSprite2D:
		var aspr := p as AnimatedSprite2D
		if on:
			aspr.visible = true
			# Choose a default animation if none
			if aspr.sprite_frames != null and not aspr.sprite_frames.get_animation_names().is_empty():
				if aspr.animation == "":
					aspr.animation = aspr.sprite_frames.get_animation_names()[0]
			# On edge only: hard restart so it doesn't resume on the last frame
			if rising:
				aspr.play()
				aspr.frame = 0
			if not aspr.is_playing():
				aspr.play()
		else:
			# let smoothing reduce speed; hide once effectively off (done in smoother)
			pass
		return

	if p is Sprite2D:
		(p as Sprite2D).visible = on

func _cancel_drift_no_award(settle_time: float) -> void:
	_is_drifting = false
	
	if _sfx and _sfx.has_method("set_drift_active"):
		_sfx.set_drift_active(false)
		
	_speedMultiplier = 1.0
	_emit_dust(false)
	_emit_sparks(false)
	_drift_release_timer = 0.0
	_post_settle_time = settle_time
	_lean_left_visual = (_drift_dir < 0)
	_drift_charge = 0.0

func _end_drift_with_award() -> void:
	# End drift, but do not force sprite changes
	_is_drifting = false
	_emit_dust(false)
	_emit_sparks(false)

	var did_award := false

	# Award: smoothed boost + temporary cap headroom
	if _drift_charge >= TURBO_THRESHOLD_BIG:
		_turbo_timer = TURBO_TIME             # keeps headroom
		_release_boost = TURBO_BIG_MULT - 1.0 # temporary boost
		_drift_release_timer = DRIFT_RELEASE_BURST_TIME
		did_award = true
		if _sfx and _sfx.has_method("play_boost"):
			_sfx.play_boost()
	elif _drift_charge >= TURBO_THRESHOLD_SMALL:
		_turbo_timer = TURBO_TIME
		_release_boost = TURBO_SMALL_MULT - 1.0
		_drift_release_timer = DRIFT_RELEASE_BURST_TIME * 0.75
		did_award = true
		if _sfx and _sfx.has_method("play_boost"):
			_sfx.play_boost()
	else:
		_drift_release_timer = 0.0

	# Reset drift charge regardless
	_drift_charge = 0.0

	# Celebration spin (visual only)
	if did_award:
		_award_spin_start()

func _in_drift_visual_state() -> bool:
	return _is_drifting or (_drift_release_timer > 0.0) or (_post_settle_time > 0.0)

func ReturnIsHopping() -> bool:
	return false

func ReturnIsDrifting() -> bool:
	return _is_drifting

# Return the player's map-space position (same space used for path/Pseudo3D)
func get_player_map_position() -> Vector2:
	return get_map_space_position()

# Return the camera forward vector in map space
func get_player_camera_forward(pseudo3d: Node) -> Vector2:
	return pseudo3d.get_camera_forward_map()

func _spinout_update_meter(dt: float, input_vec: Vector2) -> void:
	if _is_spinning:
		return

	# Require active drift AND real steering pressure to build meter
	var steer := input_vec.x
	var steer_abs = abs(steer)

	if _is_drifting and steer_abs >= SPIN_MIN_STEER:
		var add = SPIN_BUILD_BASE + SPIN_BUILD_STEER_GAIN * steer_abs
		_spin_meter += add * dt

		if _spin_meter >= SPIN_THRESHOLD:
			# require a non-zero steer to trip; define spin direction now
			if steer > 0.0:
				_drift_dir = 1
			elif steer < 0.0:
				_drift_dir = -1
			else:
				_spin_meter = SPIN_THRESHOLD - 0.01
				return
			_spinout_start()
	else:
		# quick forgiveness when you’re not applying enough steer or not drifting
		_spin_meter = max(0.0, _spin_meter - 30.0 * dt)

func _spinout_start() -> void:
	# end drift immediately, no turbo award
	_cancel_drift_no_award(0.0)

	# if somehow unset, derive from current steer so left/right is defined
	if _drift_dir == 0:
		var steer_now := ReturnPlayerInput().x
		if steer_now > 0.0:
			_drift_dir = 1
		elif steer_now < 0.0:
			_drift_dir = -1
		else:
			_drift_dir = 1  # safe default

	_is_spinning = true
	_spin_timer = SPIN_DURATION
	_spin_phase = 0.0
	_spin_meter = 0.0
	#_speedMultiplier = SPIN_SPEED_MULT

	if _sfx and _sfx.has_method("play_spin"):
		_sfx.play_spin()

	_emit_dust(true)
	_emit_sparks(true)
	_set_sparks_color(Color(1.0, 0.95, 0.65))

func _spinout_tick(dt: float) -> void:
	if not _is_spinning:
		return
	_spin_timer -= dt
	# advance phase so we can swap left/right a few times over the duration
	_spin_phase += (SPIN_ANIM_CYCLES / SPIN_DURATION) * dt  # cycles per duration

	if _spin_timer <= 0.0:
		_is_spinning = false
		_speedMultiplier = 1.0
		_emit_dust(false)
		_emit_sparks(false)
		_post_spin_lock = SPIN_RECOVER_STEER_LOCK

# Call this from Update() after computing nextPos and doing wall checks/side-slip:
# _finalize_move_with_item_comp(nextPos, mapForward)
func _finalize_move_with_item_comp(nextPos: Vector3, mapForward: Vector3) -> void:
	var nextPixelPos := Vector2i(ceil(nextPos.x), ceil(nextPos.z))
	var curr_rt = _collisionHandler.ReturnCurrentRoadType(nextPixelPos)

	# Apply terrain effects first
	HandleRoadType(nextPixelPos, curr_rt)

	# Then compensate terrain if item boost is active (requires _apply_item_terrain_comp from step 2)
	_apply_item_terrain_comp(curr_rt)

	# Finish movement for this frame
	SetMapPosition(nextPos)
	UpdateMovementSpeed()
	UpdateVelocity(mapForward)

func _recompute_speed_multiplier() -> float:
	var boost := 1.0

	# Nitro micro-boost (replaces hop)
	if _nitro_timer > 0.0:
		if NITRO_MULT > boost:
			boost = NITRO_MULT

	# Item mushroom
	if _item_boost_timer > 0.0:
		if ITEM_BOOST_MULT > boost:
			boost = ITEM_BOOST_MULT

	# Spin is a hard cap
	if _is_spinning:
		if SPIN_SPEED_MULT < boost:
			boost = SPIN_SPEED_MULT

	# Smoothed drift-release bonus
	if _release_boost > 0.0:
		var b := 1.0 + _release_boost
		if b > boost:
			boost = b

	return boost

func SetCollisionBump(bumpDir: Vector3) -> void:
	# keep impulse & pushback
	super.SetCollisionBump(bumpDir)

	# SFX: only from PLAYER (this script) with a cooldown
	if _bump_sfx_cd > 0.0:
		return
	if _sfx == null:
		return
	if not _sfx.has_method("play_bump"):
		return

	# Basic impulse gate you already exported (use magnitude of bumpDir)
	var impulse := bumpDir.length()
	if impulse < BUMP_SFX_MIN_IMPULSE:
		return

	# If the bump is pushing us in our own forward direction, it's a rear shove.
	# (rear shove → longer cooldown so repeated pushing doesn't spam)
	var rear_shove = false
	if _last_map_forward.length() > 0.0001:
		rear_shove = bumpDir.dot(_last_map_forward) > 0.0

	_sfx.play_bump()

	# base cooldown
	var cd := BUMP_SFX_COOLDOWN_S
	# stretch cooldown for rear shoves (AI riding your tail)
	if rear_shove:
		cd *= REAR_BUMP_COOLDOWN_MULT

	_bump_sfx_cd = cd


func _ensure_nitro_material() -> void:
	var sh := load(nitro_shader_path)
	if sh == null:
		push_warning("Nitro shader not found: " + nitro_shader_path)
		return
	if _nitro_mat == null:
		_nitro_mat = ShaderMaterial.new()
		_nitro_mat.shader = sh
		# static defaults; live values updated per-frame
		_nitro_mat.set_shader_parameter("glow_color", nitro_glow_color)
		_nitro_mat.set_shader_parameter("outline_px", nitro_outline_px)
		_nitro_mat.set_shader_parameter("chroma_px", 0.0)
		_nitro_mat.set_shader_parameter("intensity", 0.0)
		_nitro_mat.set_shader_parameter("dir2", Vector2(1, 0))

func _apply_nitro_fx(mapForward: Vector3) -> void:
	var spr := ReturnSpriteGraphic()
	if spr == null:
		return

	# live 0..1 “how strong is nitro right now”
	var live := 0.0
	# treat _nitro_timer as a boolean ON flag from Update()
	if _nitro_timer > 0.0:
		live = 1.0

	if live > 0.0:
		# ensure material and attach if needed
		_ensure_nitro_material()
		if _nitro_mat == null:
			return

		if spr.material != _nitro_mat:
			# remember what was there (so we can restore exactly)
			if _nitro_prev_material == null:
				_nitro_prev_material = spr.material
			spr.material = _nitro_mat

		# ease: quicker rise, gentle fall
		var eased := pow(live, 0.5)  # 0..1 (sqrt for “punchy” start)
		var inten = clamp(eased * nitro_intensity_max, 0.0, 1.0)
		var chroma = nitro_chroma_max_px * inten

		# forward in screen-UV space: use your mapForward (XZ → screen x,y sign)
		# mapForward is already normalized in your Update() caller
		var dir2 := Vector2(mapForward.x, mapForward.z)
		if dir2.length() > 0.00001:
			dir2 = dir2.normalized()
		else:
			dir2 = Vector2(1, 0)

		# feed uniforms
		_nitro_mat.set_shader_parameter("intensity", inten)
		_nitro_mat.set_shader_parameter("chroma_px", chroma)
		_nitro_mat.set_shader_parameter("dir2", dir2)
	else:
		# nitro ended: cleanly restore the original material exactly once
		if spr.material == _nitro_mat:
			if _nitro_prev_material != null:
				spr.material = _nitro_prev_material
			else:
				spr.material = null
		_nitro_prev_material = null

func CancelNitro() -> void:
	_nitro_latched = false

func _ensure_yoshi_material() -> void:
	var spr := ReturnSpriteGraphic()
	if spr == null:
		return

	# If Nitro is currently active, don't fight it here.
	if spr.material == _nitro_mat:
		return

	# Try to use whatever is already on the sprite if it's a ShaderMaterial.
	var sm: ShaderMaterial = null
	if spr.material != null and spr.material is ShaderMaterial:
		sm = spr.material as ShaderMaterial
		# Make it unique to this scene so multiple racers don't share uniforms.
		if !sm.resource_local_to_scene:
			var dupe := sm.duplicate(true) as ShaderMaterial
			dupe.resource_local_to_scene = true
			spr.material = dupe
			sm = dupe

	# If there's no ShaderMaterial, create one with your Yoshi shader.
	if sm == null:
		if !ResourceLoader.exists(yoshi_shader_path):
			return
		var sh := load(yoshi_shader_path) as Shader
		if sh == null:
			return
		sm = ShaderMaterial.new()
		sm.shader = sh
		sm.resource_local_to_scene = true
		spr.material = sm

	# Track the base material for sanity (not strictly required anymore).
	_yoshi_mat = sm

func IsUsingNitroMaterial() -> bool:
	var spr := ReturnSpriteGraphic()
	if spr == null: return false
	return spr.material == _nitro_mat

func _has_collision_api() -> bool:
	return _collisionHandler != null \
		and _collisionHandler.has_method("IsCollidingWithWall") \
		and _collisionHandler.has_method("ReturnCurrentRoadType")

func _award_spin_start() -> void:
	if _is_spinning:
		return
	_is_award_spin = true
	_award_spin_elapsed = 0.0

	var dir := 1  # +1 = right spin, -1 = left spin

	# 1) If we were drifting, use that turn’s sign (most accurate).
	if _drift_dir != 0:
		dir = (-1 if _drift_dir < 0 else 1)
	else:
		# 2) Otherwise use the live steering input if it’s meaningful.
		var steer_now := ReturnPlayerInput().x
		var STEER_SPIN_THRESH := 0.12  # ignore tiny noise around center
		if steer_now <= -STEER_SPIN_THRESH:
			dir = -1
		elif steer_now >=  STEER_SPIN_THRESH:
			dir =  1
		else:
			# 3) Last resort: current visual lean.
			dir = (-1 if _lean_left_visual else 1)

	_award_spin_dir = dir


func _award_spin_tick(dt: float) -> void:
	if not _is_award_spin:
		return
	_award_spin_elapsed += dt
	if _award_spin_elapsed >= AWARD_SPIN_DURATION:
		_is_award_spin = false
		_award_spin_elapsed = AWARD_SPIN_DURATION
		
func _apply_award_spin_frames() -> void:
	# progress 0..1 over the celebration
	var t := 0.0
	if AWARD_SPIN_DURATION > 0.0:
		t = _award_spin_elapsed / AWARD_SPIN_DURATION
	if t < 0.0:
		t = 0.0
	if t > 1.0:
		t = 1.0

	# map to angle; split into 0..180 and 180..360 halves
	var total_deg := 360.0 * AWARD_SPIN_ROTATIONS * t
	var local_deg := fmod(total_deg, 360.0)
	if local_deg < 0.0:
		local_deg += 360.0

	var half := 0
	if local_deg >= 180.0:
		half = 1
		local_deg -= 180.0

	var frames := FRAMES_PER_ROW            # you have 12 right-facing frames
	if frames < 1:
		frames = 1
	var steps := frames - 1                 # 0..11 usable steps across 180°

	var u := local_deg / 180.0              # 0..1 within this half
	var idx_half := int(floor(u * float(steps) + 0.0001))
	if idx_half < 0:
		idx_half = 0
	if idx_half > steps:
		idx_half = steps

	# compute a 0..23 "direction index" for _set_frame_idx when mirroring is used
	# pattern (RIGHT spin):   half0 → 0..11, half1 → 23..12 (reverse+flip)
	# pattern (LEFT spin):    half0 → 11..0 (reverse+flip), half1 → 12..23
	var dir_right := (_award_spin_dir >= 0)
	var dir_idx := 0
	var flip := false

	if dir_right:
		if half == 0:
			dir_idx = idx_half                 # 0..11
			flip = false
		else:
			dir_idx = (frames * 2 - 1) - idx_half   # 23..12
			flip = true
	else:
		if half == 0:
			dir_idx = steps - idx_half         # 11..0
			flip = true
		else:
			dir_idx = frames + idx_half        # 12..23
			flip = false

	# push to sprite:
	# if your base supports mirroring (12 frames + flip), use _set_frame_idx(dir_idx)
	# otherwise: set the base frame and apply flip manually after
	var use_mirror := false
	if "sheet_uses_mirroring" in self:
		use_mirror = sheet_uses_mirroring

	if use_mirror:
		_set_frame_idx(dir_idx)               # will set flip internally
	else:
		var base_idx := dir_idx % frames      # 0..11
		_set_frame(base_idx)                  # sets frame (resets flip)
		_set_flip_h(flip)                     # then apply the flip

# --- Color resolution strictly per player index (no globals racing) ---

func _resolve_selected_name_for_slot() -> String:
	var nm := ""
	if Globals.has_method("get_selected_racer_for_slot"):
		nm = String(Globals.get_selected_racer_for_slot(_player_index))
	if nm == "":
		nm = String(Globals.selected_racer)
	return nm

func _resolve_selected_color_for_slot() -> Color:
	var col := Color.WHITE
	if Globals.has_method("get_selected_color_for_slot"):
		col = Globals.get_selected_color_for_slot(_player_index)
	if col == Color.WHITE or col.a == 0.0:
		var nm := _resolve_selected_name_for_slot()
		col = Globals.get_racer_color(nm)
	return col

func _apply_player_palette_from_globals() -> void:
	var spr := ReturnSpriteGraphic()
	if spr == null:
		return
	if spr.material == _nitro_mat:
		return

	_ensure_yoshi_material()

	var col := _resolve_selected_color_for_slot()
	var sm := spr.material
	if sm != null and sm is ShaderMaterial and (sm as ShaderMaterial).shader != null:
		var sh := sm as ShaderMaterial
		sh.set_shader_parameter("target_color", col)
		sh.set_shader_parameter("src_hue",     yoshi_source_hue)
		sh.set_shader_parameter("hue_tol",     yoshi_tolerance)
		sh.set_shader_parameter("edge_soft",   yoshi_edge_soft)
	else:
		spr.modulate = col

func RefreshPaletteFromGlobals() -> void:
	_ensure_yoshi_material()
	_apply_player_palette_from_globals()
